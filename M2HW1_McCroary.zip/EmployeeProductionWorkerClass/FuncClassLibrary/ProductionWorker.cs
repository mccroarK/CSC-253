﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuncClassLibrary
{
    public class ProductionWorker : Employee
    {
        // Default Constructor
        public ProductionWorker() : base()
        {
            ShiftNumber = 0;
            HourlyPayRate = 0m;
        }

        // Properties
        public int ShiftNumber { get; set; }
        public decimal HourlyPayRate { get; set; }
    }
}
