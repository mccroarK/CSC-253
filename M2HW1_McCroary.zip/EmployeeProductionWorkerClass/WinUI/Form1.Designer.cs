﻿
namespace WinUI
{
    partial class employeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeeGroupBox = new System.Windows.Forms.GroupBox();
            this.productionGroupBox = new System.Windows.Forms.GroupBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.number = new System.Windows.Forms.Label();
            this.hourlyPayLabel = new System.Windows.Forms.Label();
            this.shiftNumLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.helpLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.enterButton = new System.Windows.Forms.Button();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.shiftNumTextBox = new System.Windows.Forms.TextBox();
            this.hourlyPayTextBox = new System.Windows.Forms.TextBox();
            this.employeeGroupBox.SuspendLayout();
            this.productionGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeeGroupBox
            // 
            this.employeeGroupBox.Controls.Add(this.numberTextBox);
            this.employeeGroupBox.Controls.Add(this.nameTextBox);
            this.employeeGroupBox.Controls.Add(this.number);
            this.employeeGroupBox.Controls.Add(this.nameLabel);
            this.employeeGroupBox.Location = new System.Drawing.Point(50, 94);
            this.employeeGroupBox.Name = "employeeGroupBox";
            this.employeeGroupBox.Size = new System.Drawing.Size(259, 85);
            this.employeeGroupBox.TabIndex = 0;
            this.employeeGroupBox.TabStop = false;
            this.employeeGroupBox.Text = "Employee Properties";
            // 
            // productionGroupBox
            // 
            this.productionGroupBox.Controls.Add(this.hourlyPayTextBox);
            this.productionGroupBox.Controls.Add(this.shiftNumTextBox);
            this.productionGroupBox.Controls.Add(this.hourlyPayLabel);
            this.productionGroupBox.Controls.Add(this.shiftNumLabel);
            this.productionGroupBox.Location = new System.Drawing.Point(50, 185);
            this.productionGroupBox.Name = "productionGroupBox";
            this.productionGroupBox.Size = new System.Drawing.Size(259, 85);
            this.productionGroupBox.TabIndex = 1;
            this.productionGroupBox.TabStop = false;
            this.productionGroupBox.Text = "Production Worker Properties";
            // 
            // nameLabel
            // 
            this.nameLabel.Location = new System.Drawing.Point(6, 28);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(100, 23);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name:";
            this.nameLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // number
            // 
            this.number.Location = new System.Drawing.Point(6, 51);
            this.number.Name = "number";
            this.number.Size = new System.Drawing.Size(100, 23);
            this.number.TabIndex = 1;
            this.number.Text = "Number:";
            this.number.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // hourlyPayLabel
            // 
            this.hourlyPayLabel.Location = new System.Drawing.Point(6, 52);
            this.hourlyPayLabel.Name = "hourlyPayLabel";
            this.hourlyPayLabel.Size = new System.Drawing.Size(100, 23);
            this.hourlyPayLabel.TabIndex = 3;
            this.hourlyPayLabel.Text = "Hourly Pay:";
            this.hourlyPayLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // shiftNumLabel
            // 
            this.shiftNumLabel.Location = new System.Drawing.Point(6, 29);
            this.shiftNumLabel.Name = "shiftNumLabel";
            this.shiftNumLabel.Size = new System.Drawing.Size(100, 23);
            this.shiftNumLabel.TabIndex = 2;
            this.shiftNumLabel.Text = "Shift Number:";
            this.shiftNumLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(30, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(309, 29);
            this.titleLabel.TabIndex = 4;
            this.titleLabel.Text = "Production Worker Maker";
            // 
            // helpLabel
            // 
            this.helpLabel.Location = new System.Drawing.Point(12, 38);
            this.helpLabel.Name = "helpLabel";
            this.helpLabel.Size = new System.Drawing.Size(347, 40);
            this.helpLabel.TabIndex = 5;
            this.helpLabel.Text = "Fill in employee and production worker properties to create an instance of the Pr" +
    "oductionWorker class.";
            this.helpLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(291, 335);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(234, 276);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(75, 23);
            this.enterButton.TabIndex = 2;
            this.enterButton.Text = "Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // nameTextBox
            // 
            this.nameTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameTextBox.Location = new System.Drawing.Point(112, 26);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(141, 22);
            this.nameTextBox.TabIndex = 0;
            // 
            // numberTextBox
            // 
            this.numberTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberTextBox.Location = new System.Drawing.Point(112, 49);
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(141, 22);
            this.numberTextBox.TabIndex = 1;
            // 
            // shiftNumTextBox
            // 
            this.shiftNumTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.shiftNumTextBox.Location = new System.Drawing.Point(112, 27);
            this.shiftNumTextBox.Name = "shiftNumTextBox";
            this.shiftNumTextBox.Size = new System.Drawing.Size(141, 22);
            this.shiftNumTextBox.TabIndex = 0;
            // 
            // hourlyPayTextBox
            // 
            this.hourlyPayTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hourlyPayTextBox.Location = new System.Drawing.Point(112, 50);
            this.hourlyPayTextBox.Name = "hourlyPayTextBox";
            this.hourlyPayTextBox.Size = new System.Drawing.Size(141, 22);
            this.hourlyPayTextBox.TabIndex = 1;
            // 
            // employeeForm
            // 
            this.AcceptButton = this.enterButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(378, 370);
            this.Controls.Add(this.enterButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.helpLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.productionGroupBox);
            this.Controls.Add(this.employeeGroupBox);
            this.Name = "employeeForm";
            this.Text = "Employee and Production Worker";
            this.employeeGroupBox.ResumeLayout(false);
            this.employeeGroupBox.PerformLayout();
            this.productionGroupBox.ResumeLayout(false);
            this.productionGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox employeeGroupBox;
        private System.Windows.Forms.Label number;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.GroupBox productionGroupBox;
        private System.Windows.Forms.Label hourlyPayLabel;
        private System.Windows.Forms.Label shiftNumLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label helpLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox hourlyPayTextBox;
        private System.Windows.Forms.TextBox shiftNumTextBox;
    }
}

