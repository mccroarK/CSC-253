﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FuncClassLibrary;

/**
* 9/24/2023
* CSC 253
* Kevin McCroary
* Allows user to input information to create a Production Worker class, a subclass of the Employee class.
*/

namespace WinUI
{
    public partial class employeeForm : Form
    {
        public employeeForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the program
            Close();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            // Create an instance of the ProductionWorker class
            ProductionWorker worker = new ProductionWorker();

            // Information variables
            int num;
            int shiftnum;
            decimal hourlypay;

            // Try to enter in information

            // Enter name
            worker.Name = nameTextBox.Text;

            if (int.TryParse(numberTextBox.Text, out num))
            {
                // Enter number
                worker.Number = num;
            }

            if (int.TryParse(shiftNumTextBox.Text, out shiftnum))
            {
                // If shiftnum is 1 or 2
                if (shiftnum == 1 || shiftnum == 2)
                {
                    // Enter shift number
                    worker.ShiftNumber = shiftnum;
                }

                // If shiftnum is not 1 or 2
                else
                {
                    MessageBox.Show("Shift Number needs to be 1 or 2. (1 = Day, 2 = Night)");
                }
            }

            if (decimal.TryParse(hourlyPayTextBox.Text, out hourlypay))
            {
                // Enter hourly pay rate
                worker.HourlyPayRate = hourlypay;
            }

            // Display information
            MessageBox.Show(
                $"Name:\t\t{worker.Name}" +
                $"\nNumber:\t\t{worker.Number}" +
                $"\nShift Number:\t{worker.ShiftNumber}" +
                $"\nHourly Pay:\t{worker.HourlyPayRate.ToString("c")}");
        }
    }
}
