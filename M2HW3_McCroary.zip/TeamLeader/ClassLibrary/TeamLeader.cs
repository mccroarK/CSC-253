﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class TeamLeader : ProductionWorker
    {
        // Default constructor
        public TeamLeader() : base()
        {
            MonthlyBonus = 0;
            ReqTrainingHours = 0;
            DoneTrainingHours = 0;
        }
        
        // Constructor
        public TeamLeader(string name, int number, int shiftnum, decimal hourlypay, decimal monthlybonus, int reqhours, int donehours) : base(name, number, shiftnum, hourlypay)
        {
            MonthlyBonus = monthlybonus;
            ReqTrainingHours = reqhours;
            DoneTrainingHours = donehours;
        }

        // Properties
        public decimal MonthlyBonus { get; set; }
        public int ReqTrainingHours { get; set; }
        public int DoneTrainingHours { get; set; }

        // Method
        public override string GetInfo()
        {
            return $"Team Leader\n" +
                $"Name:\t\t{Name}\n" +
                $"Number:\t\t{Number}\n" +
                $"Shift Number:\t{ShiftNumber}\n" +
                $"Hourly Pay:\t{HourlyPayRate.ToString("c")}\n" +
                $"Monthly Bonus:\t{MonthlyBonus.ToString("c")}\n" +
                $"Req. Training\n" +                                    // Done for space
                $"Hours:\t\t{ReqTrainingHours}\n" +
                $"Attended Hours:\t{DoneTrainingHours}\n";
        }
    }
}
