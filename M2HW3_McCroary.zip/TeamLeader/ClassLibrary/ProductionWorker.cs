﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class ProductionWorker: Employee
    {
        // Default Constructor
        public ProductionWorker() : base()
        {
            ShiftNumber = 0;
            HourlyPayRate = 0m;
        }

        // Constructor
        public ProductionWorker(string name, int number, int shiftnum, decimal hourlypay) : base(name, number)
        {
            ShiftNumber = shiftnum;
            HourlyPayRate = hourlypay;
        }

        // Properties
        public int ShiftNumber { get; set; }
        public decimal HourlyPayRate { get; set; }

        // Method
        public override string GetInfo()
        {
            return $"Production Worker\n" +
                $"Name:\t\t{Name}\n" +
                $"Number:\t\t{Number}\n" +
                $"Shift Number:\t{ShiftNumber}\n" +
                $"Hourly Pay:\t{HourlyPayRate.ToString("c")}";
        }
    }
}
