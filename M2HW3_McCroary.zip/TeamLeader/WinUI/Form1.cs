﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;

/**
* 9/27/2023
* CSC 253
* Kevin McCroary
* Lets the user create a TeamLeader class or other by inputting information
*/

namespace WinUI
{

    public partial class teamLeaderForm : Form
    {
        // Class Choices for combo box
        public string[] class_choices = new string[3]
        {
            "Employee",
            "Production Worker",
            "Team Leader",
        };

        // Shift numbers
        public string[] shift_nums = new string[2]
        {
            "1 (Day)",
            "2 (Night)"
        };

        public teamLeaderForm()
        {
            InitializeComponent();
        }

        private void classComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Switch depending on user class choice
            switch (classComboBox.SelectedIndex)
            {
                // Class choice is employee
                case 0:
                    // Enable employee group box
                    employeeGroupBox.Enabled = true;
                    prodworkerGroupBox.Enabled = false;
                    teamleaderGroupBox.Enabled = false;
                    // Break because for some reason I cannot fall through in this
                    break;

                // Class choice is production worker
                case 1:
                    // Enable employee and production worker group boxes
                    employeeGroupBox.Enabled = true;
                    prodworkerGroupBox.Enabled = true;
                    teamleaderGroupBox.Enabled = false;
                    // Break
                    break;

                // Class chosen is Team Leader
                default:
                    // Enable all group boxes
                    employeeGroupBox.Enabled = true;
                    prodworkerGroupBox.Enabled = true;
                    teamleaderGroupBox.Enabled = true;
                    // Break
                    break;
            }
        }

        private void teamLeaderForm_Load(object sender, EventArgs e)
        {
            // Get the data source for the combo box
            classComboBox.DataSource = class_choices;

            // Get the data source for the shift numbers
            shiftNumComboBox.DataSource = shift_nums;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            Close();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            // Create variables
            Employee worker;        // Class object
            string name;            // Employee name
            int num;                // Employee number
            int shiftnum;           // ProductionWorker shift number
            decimal hourlypay;      // ProductionWorker hourly pay
            decimal monthlybonus;   // TeamLeader montly bonus
            int reqhours;           // TeamLeader required training hours
            int donehours;          // TeamLeader training hours attended

            // Initialize name
            name = nameTextBox.Text;

            // Add to shift number combo box selected index
            shiftnum = shiftNumComboBox.SelectedIndex + 1;

            // TryParse input
            // If Employee number input is bad
            if(!int.TryParse(numberTextBox.Text, out num))
            {
                // Employee number is 0
                num = 0;
            }

            // If ProductionWorker hourly pay input is bad
            if(!decimal.TryParse(hourlyPayTextBox.Text, out hourlypay))
            {
                // ProductionWorker hourly pay is $0.00
                hourlypay = 0;
            }

            // If TeamLeader monthly bonus input is bad
            if(!decimal.TryParse(monthlyBonusTextBox.Text, out monthlybonus))
            {
                // TeamLeader monthly bonus is $0.00
                monthlybonus = 0;
            }

            // If TeamLeader required training hours input is bad
            if (!int.TryParse(numberTextBox.Text, out reqhours))
            {
                // TeamLeader required training hours is 0
                reqhours = 0;
            }

            // If TeamLeader training hours attended input is bad
            if (!int.TryParse(numberTextBox.Text, out donehours))
            {
                // TeamLeader training hours attended is 0
                donehours = 0;
            }

            // Instantiate the variable using a switch
            switch (classComboBox.SelectedIndex)
            {
                // Employee chosen
                case 0:
                    // Create worker as Employee
                    worker = new Employee(name, num);
                    // Break
                    break;

                // Production worker chosen
                case 1:
                    // Create worker as ProductionWorker
                    worker = (ProductionWorker)new ProductionWorker(name, num, shiftnum, hourlypay);
                    // Break
                    break;

                // Team Leader chosen
                default:
                    // Create worker as TeamLeader
                    worker = (TeamLeader)new TeamLeader(name, num, shiftnum, hourlypay, monthlybonus, reqhours, donehours);
                    // Break
                    break;
            }

            // Display info in message box
            MessageBox.Show(worker.GetInfo());
        }
    }
}
