﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FuncLibrary;

/**
* 9/10/2023
* CSC 253
* Kevin McCroary
* Displays course information from a selected course number
*/

namespace WinUI
{
    public partial class courseForm : Form
    {
        static string[] courseNumbers =
        {
            "CS101",
            "CS102",
            "CS103",
            "NT110",
            "CM241",
        };

        public courseForm()
        {
            InitializeComponent();
        }

        private void courseForm_Load(object sender, EventArgs e)
        {
            courseBox.DataSource = courseNumbers;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            Course course = CourseInfo.GetInfo(courseBox.SelectedItem.ToString());
            MessageBox.Show(course.DisplayInfo());
        }
    }
}
