﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuncLibrary
{
    public struct Course
    {
        public string number;
        public int room;
        public string teacher;
        public string time;

        public string DisplayNumber()
        {
            return $"{number}";
        }

        public string DisplayRoom()
        {
            if (room > 0)
            {
                return $"Room:\t\t{room}";
            }
            else
            {
                return "There is no room for this course";
            }
        }

        public string DisplayTeacher()
        {
            if (teacher != "")
            {
                return $"Instructor:\t{teacher}";
            }
            else
            {
                return "There is no instructor for this course";
            }
        }

        public string DisplayTime()
        {
            if (time != "")
            {
                return $"Time:\t\t{time}";
            }
            else
            {
                return "There is no time for this course";
            }
        }

        public string DisplayInfo()
        {
            return $"{DisplayNumber()}\n{DisplayRoom()}\n{DisplayTeacher()}\n{DisplayTime()}";
        }
    }
}
