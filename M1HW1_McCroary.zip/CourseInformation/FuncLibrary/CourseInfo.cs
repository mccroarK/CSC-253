﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuncLibrary
{
    public enum CourseNum
    {
        CS101,
        CS102,
        CS103,
        NT110,
        CM241
    }
    public static class CourseInfo
    {
        // Rooms dictionary
        static Dictionary<string, int> rooms = new Dictionary<string, int>()
        {
            {"CS101", 3004},
            {"CS102", 4501},
            {"CS103", 6755},
            {"NT110", 1244},
            {"CM241", 1411},
        };
        // Instructors dictionary
        static Dictionary<string, string> teachers = new Dictionary<string, string>()
        {
            {"CS101", "Haynes"},
            {"CS102", "Alvarado"},
            {"CS103", "Rich"},
            {"NT110", "Burke"},
            {"CM241", "Lee"},
        };
        // Meeting Times Dictionary
        static Dictionary<string, string> times = new Dictionary<string, string>()
        {
            {"CS101", "8:00 AM"},
            {"CS102", "9:00 AM"},
            {"CS103", "10:00 AM"},
            {"NT110", "11:00 AM"},
            {"CM241", "1:00 PM"},
        };
        public static Course GetInfo(string key)
        {
            // Create a course struct
            Course course = new Course();

            // Fill course number
            course.number = key;

            // Course variables
            int room;
            string teacher;
            string time;

            // Check if string key is in the dictionaries
            if (rooms.TryGetValue(key, out room))
            {
                // Fill the course room
                course.room = room;
            }
            if (teachers.TryGetValue(key, out teacher))
            {
                // Fill the course teacher
                course.teacher = teacher;
            }
            if (times.TryGetValue(key, out time))
            {
                // Fill the course time
                course.time = time;
            }
            
            // Return the course
            return course;
        }
    }
}
