﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.positiveListBox = new System.Windows.Forms.ListBox();
            this.list1Label = new System.Windows.Forms.Label();
            this.list2Label = new System.Windows.Forms.Label();
            this.rangeListBox = new System.Windows.Forms.ListBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.infoLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(70, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(198, 29);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "List Manipulator";
            // 
            // positiveListBox
            // 
            this.positiveListBox.FormattingEnabled = true;
            this.positiveListBox.ItemHeight = 16;
            this.positiveListBox.Location = new System.Drawing.Point(12, 110);
            this.positiveListBox.Name = "positiveListBox";
            this.positiveListBox.Size = new System.Drawing.Size(157, 180);
            this.positiveListBox.TabIndex = 1;
            // 
            // list1Label
            // 
            this.list1Label.Location = new System.Drawing.Point(12, 90);
            this.list1Label.Name = "list1Label";
            this.list1Label.Size = new System.Drawing.Size(157, 17);
            this.list1Label.TabIndex = 2;
            this.list1Label.Text = "Positive Numbers";
            this.list1Label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // list2Label
            // 
            this.list2Label.Location = new System.Drawing.Point(175, 90);
            this.list2Label.Name = "list2Label";
            this.list2Label.Size = new System.Drawing.Size(157, 17);
            this.list2Label.TabIndex = 4;
            this.list2Label.Text = "Numbers from 1-10";
            this.list2Label.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // rangeListBox
            // 
            this.rangeListBox.FormattingEnabled = true;
            this.rangeListBox.ItemHeight = 16;
            this.rangeListBox.Location = new System.Drawing.Point(175, 110);
            this.rangeListBox.Name = "rangeListBox";
            this.rangeListBox.Size = new System.Drawing.Size(157, 180);
            this.rangeListBox.TabIndex = 3;
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(257, 296);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // infoLabel
            // 
            this.infoLabel.Location = new System.Drawing.Point(12, 38);
            this.infoLabel.Name = "infoLabel";
            this.infoLabel.Size = new System.Drawing.Size(320, 39);
            this.infoLabel.TabIndex = 6;
            this.infoLabel.Text = "Creates 2 lists from a file with 100 random integers";
            this.infoLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(344, 327);
            this.Controls.Add(this.infoLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.list2Label);
            this.Controls.Add(this.rangeListBox);
            this.Controls.Add(this.list1Label);
            this.Controls.Add(this.positiveListBox);
            this.Controls.Add(this.titleLabel);
            this.Name = "Form1";
            this.Text = "List Manipulator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.ListBox positiveListBox;
        private System.Windows.Forms.Label list1Label;
        private System.Windows.Forms.Label list2Label;
        private System.Windows.Forms.ListBox rangeListBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label infoLabel;
    }
}

