﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ListLibrary;

/**
* 10/21/2023
* CSC 253
* Kevin McCroary
* Creates and lists a positive integer list and an integer list with a range from 1-10 using lambda expressions
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Create a Func delegate
            Func<List<int>> MakeList = () => ListBuilder.Build();

            // Create a list from the random file and remove all negative integers
            List<int> positiveList = MakeList();
            positiveList.RemoveAll(x => x < 0);

            // Create a list from the random file from a range between 1 - 10
            List<int> rangeList = MakeList().FindAll(x => 1 <= x && x <= 10);

            // Assign positive list box to positive list
            positiveListBox.DataSource = positiveList;

            // Assign range list box to range list
            rangeListBox.DataSource = rangeList;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
