﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ListLibrary
{
    public static class ListBuilder
    {
        public static List<int> Build()
        {
            // Empty list
            List<int> returnlist = new List<int>();

            // Build a list out of the 100 random integers
            using (StreamReader reader = File.OpenText(@"..\..\..\ListLibrary\Docs\random.txt"))
            {
                // While the file is not fully read
                while (!reader.EndOfStream)
                {
                    // Add each line to the list
                    returnlist.Add(int.Parse(reader.ReadLine()));
                }
            }

            // Return the file list
            return returnlist;
        }
    }
}
