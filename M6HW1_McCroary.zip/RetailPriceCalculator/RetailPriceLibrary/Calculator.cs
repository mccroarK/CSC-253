﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace RetailPriceLibrary
{
    public static class Calculator
    {
        public static decimal GetCost(decimal price, int percent)
        {
            // Make cost variable
            decimal cost;

            // Get cost using price and percent of price
            cost = price + (price * (((decimal) percent / 100)));

            // Return cost
            return cost;
        }
    }
}
