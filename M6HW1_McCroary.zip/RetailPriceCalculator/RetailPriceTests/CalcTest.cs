﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using RetailPriceLibrary;

namespace RetailPriceTests
{
    [TestClass]
    public class CalcTest
    {
        [TestMethod]
        public void TestCostCalc()
        {
            // Get expected answer
            decimal expected_ans = 7.50m;

            // Get example parameters
            decimal item_cost = 5;
            int markup_percent = 50;

            // Get actual answer
            decimal actual_ans = Calculator.GetCost(item_cost, markup_percent);

            // Check if expected and actual answers are equal
            Assert.AreEqual(expected_ans, actual_ans, "Item cost not calculated correctly");
        }
    }
}
