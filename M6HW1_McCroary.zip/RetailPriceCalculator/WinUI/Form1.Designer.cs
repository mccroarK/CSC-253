﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLBL = new System.Windows.Forms.Label();
            this.wholesaleLBL = new System.Windows.Forms.Label();
            this.moneyLBL = new System.Windows.Forms.Label();
            this.wholesaleTB = new System.Windows.Forms.TextBox();
            this.closeBTN = new System.Windows.Forms.Button();
            this.retailLBL = new System.Windows.Forms.Label();
            this.retailCostLBL = new System.Windows.Forms.Label();
            this.infoLBL = new System.Windows.Forms.Label();
            this.markupLBL = new System.Windows.Forms.Label();
            this.markupTB = new System.Windows.Forms.TextBox();
            this.percentLBL = new System.Windows.Forms.Label();
            this.calcBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // titleLBL
            // 
            this.titleLBL.AutoSize = true;
            this.titleLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLBL.Location = new System.Drawing.Point(13, 9);
            this.titleLBL.Name = "titleLBL";
            this.titleLBL.Size = new System.Drawing.Size(274, 29);
            this.titleLBL.TabIndex = 0;
            this.titleLBL.Text = "Retail Price Calculator";
            // 
            // wholesaleLBL
            // 
            this.wholesaleLBL.Location = new System.Drawing.Point(35, 90);
            this.wholesaleLBL.Name = "wholesaleLBL";
            this.wholesaleLBL.Size = new System.Drawing.Size(100, 23);
            this.wholesaleLBL.TabIndex = 1;
            this.wholesaleLBL.Text = "Item cost:";
            this.wholesaleLBL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // moneyLBL
            // 
            this.moneyLBL.AutoSize = true;
            this.moneyLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moneyLBL.Location = new System.Drawing.Point(15, 112);
            this.moneyLBL.Name = "moneyLBL";
            this.moneyLBL.Size = new System.Drawing.Size(14, 16);
            this.moneyLBL.TabIndex = 2;
            this.moneyLBL.Text = "$";
            this.moneyLBL.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // wholesaleTB
            // 
            this.wholesaleTB.Location = new System.Drawing.Point(35, 109);
            this.wholesaleTB.Name = "wholesaleTB";
            this.wholesaleTB.Size = new System.Drawing.Size(100, 22);
            this.wholesaleTB.TabIndex = 0;
            // 
            // closeBTN
            // 
            this.closeBTN.Location = new System.Drawing.Point(212, 252);
            this.closeBTN.Name = "closeBTN";
            this.closeBTN.Size = new System.Drawing.Size(75, 23);
            this.closeBTN.TabIndex = 3;
            this.closeBTN.Text = "Close";
            this.closeBTN.UseVisualStyleBackColor = true;
            this.closeBTN.Click += new System.EventHandler(this.closeBTN_Click);
            // 
            // retailLBL
            // 
            this.retailLBL.Location = new System.Drawing.Point(97, 179);
            this.retailLBL.Name = "retailLBL";
            this.retailLBL.Size = new System.Drawing.Size(100, 23);
            this.retailLBL.TabIndex = 5;
            this.retailLBL.Text = "Retail cost:";
            this.retailLBL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // retailCostLBL
            // 
            this.retailCostLBL.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.retailCostLBL.Location = new System.Drawing.Point(97, 202);
            this.retailCostLBL.Name = "retailCostLBL";
            this.retailCostLBL.Size = new System.Drawing.Size(100, 23);
            this.retailCostLBL.TabIndex = 6;
            // 
            // infoLBL
            // 
            this.infoLBL.Location = new System.Drawing.Point(14, 38);
            this.infoLBL.Name = "infoLBL";
            this.infoLBL.Size = new System.Drawing.Size(272, 32);
            this.infoLBL.TabIndex = 7;
            this.infoLBL.Text = "Input an item\'s wholsesale cost and markup percentage to get the retail price.";
            this.infoLBL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // markupLBL
            // 
            this.markupLBL.AutoSize = true;
            this.markupLBL.Location = new System.Drawing.Point(160, 90);
            this.markupLBL.Name = "markupLBL";
            this.markupLBL.Size = new System.Drawing.Size(101, 16);
            this.markupLBL.TabIndex = 8;
            this.markupLBL.Text = "Markup Percent";
            this.markupLBL.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // markupTB
            // 
            this.markupTB.Location = new System.Drawing.Point(161, 109);
            this.markupTB.Name = "markupTB";
            this.markupTB.Size = new System.Drawing.Size(100, 22);
            this.markupTB.TabIndex = 1;
            // 
            // percentLBL
            // 
            this.percentLBL.AutoSize = true;
            this.percentLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.percentLBL.Location = new System.Drawing.Point(267, 112);
            this.percentLBL.Name = "percentLBL";
            this.percentLBL.Size = new System.Drawing.Size(19, 16);
            this.percentLBL.TabIndex = 10;
            this.percentLBL.Text = "%";
            // 
            // calcBTN
            // 
            this.calcBTN.Location = new System.Drawing.Point(97, 137);
            this.calcBTN.Name = "calcBTN";
            this.calcBTN.Size = new System.Drawing.Size(100, 23);
            this.calcBTN.TabIndex = 2;
            this.calcBTN.Text = "Calculate";
            this.calcBTN.UseVisualStyleBackColor = true;
            this.calcBTN.Click += new System.EventHandler(this.calcBTN_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calcBTN;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.closeBTN;
            this.ClientSize = new System.Drawing.Size(301, 287);
            this.Controls.Add(this.calcBTN);
            this.Controls.Add(this.percentLBL);
            this.Controls.Add(this.markupTB);
            this.Controls.Add(this.markupLBL);
            this.Controls.Add(this.infoLBL);
            this.Controls.Add(this.retailCostLBL);
            this.Controls.Add(this.retailLBL);
            this.Controls.Add(this.closeBTN);
            this.Controls.Add(this.wholesaleTB);
            this.Controls.Add(this.moneyLBL);
            this.Controls.Add(this.wholesaleLBL);
            this.Controls.Add(this.titleLBL);
            this.Name = "Form1";
            this.Text = "Retail Price Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLBL;
        private System.Windows.Forms.Label wholesaleLBL;
        private System.Windows.Forms.Label moneyLBL;
        private System.Windows.Forms.TextBox wholesaleTB;
        private System.Windows.Forms.Button closeBTN;
        private System.Windows.Forms.Label retailLBL;
        private System.Windows.Forms.Label retailCostLBL;
        private System.Windows.Forms.Label infoLBL;
        private System.Windows.Forms.Label markupLBL;
        private System.Windows.Forms.TextBox markupTB;
        private System.Windows.Forms.Label percentLBL;
        private System.Windows.Forms.Button calcBTN;
    }
}

