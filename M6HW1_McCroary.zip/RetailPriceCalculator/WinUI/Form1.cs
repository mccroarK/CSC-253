﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailPriceLibrary;

/**
* 19/9/2023
* CSC 253
* Kevin McCroary
* Get retail price of an item using user inputted wholesale cost and markup percent
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void closeBTN_Click(object sender, EventArgs e)
        {
            // Close app
            Close();
        }

        private void calcBTN_Click(object sender, EventArgs e)
        {
            // Calculate retail cost of product
            try
            {
                // Convert input to proper datatypes and calculate price, then print
                retailCostLBL.Text = Calculator.GetCost(decimal.Parse(wholesaleTB.Text), int.Parse(markupTB.Text)).ToString("c");
            }

            // If error occurs
            catch (Exception error)
            {
                // Print error message
                MessageBox.Show(error.Message); 
            }
        }
    }
}
