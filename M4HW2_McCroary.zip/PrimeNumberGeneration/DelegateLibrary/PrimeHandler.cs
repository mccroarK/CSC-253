﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateLibrary
{
    public static class PrimeHandler
    {
        public static List<int> CountTo(int value)
        {
            // Create list
            List<int> returnlist = new List<int>();

            // Count to the value and list all prior values
            for (int i = 0; i <= value; i++)
            {
                returnlist.Add(i);
            }

            // Return the list
            return returnlist;
        }

        public static List<int> ListPrimes(List<int> list)
        {
            // Is 1 a prime number???
            // Find all prime numbers
            return list.FindAll(x =>
            {
                // Get the factor count
                int factorcount = 0;

                // Count to x
                for (int i = 1; i <= x; i++)
                {
                    // If i is a factor
                    if (x % i == 0)
                    {
                        // Add to the factor count
                        factorcount++;
                    }
                }

                // Check if the factor count is two (1 and itself)
                return factorcount == 2;
            }
            );
        }
    }
}
