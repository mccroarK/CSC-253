﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DelegateLibrary;

/**
* 10/21/2023
* CSC 253
* Kevin McCroary
* Allows user to enter a value greater than 1 and see all the prime numbers prior to and including the inputted value.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the program
            Close();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Convert user input to an int
                int input = int.Parse(inputTextBox.Text);

                // If input is greater than 1
                if (input > 1)
                {
                    // Get a list of values counting to inputted integer
                    List<int> intList = PrimeHandler.CountTo(input);

                    // Get the prime numbers
                    List<int> primeList = PrimeHandler.ListPrimes(intList);

                    // Display to list box
                    primeListBox.DataSource = primeList;
                }
                // If input is less than or equal to 1
                else
                {
                    MessageBox.Show("Enter an interger GREATER than 1.");
                }
            }
            catch (Exception error)
            {
                // User types incorrect input
                MessageBox.Show(error.Message);
            }
        }
    }
}
