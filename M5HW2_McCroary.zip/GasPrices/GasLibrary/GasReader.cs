﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GasLibrary
{
    public static class GasReader
    {
        // All Gas Info
        public static List<GasInfo> allGasInfo = new List<GasInfo>();

        // Gas Average Price per Year
        public static Dictionary<int, decimal> avgPricePerYear = new Dictionary<int, decimal>();

        // Gas Average Price per Month
        public static Dictionary<int, decimal> avgPricePerMonth = new Dictionary<int, decimal>();

        // Gas Highest and Lowest per Year
        public static Dictionary<int, GasInfo[]> highLowPerYear = new Dictionary<int, GasInfo[]>();

        public static void Run()
        {
            // Read the Gas Prices file
            using (StreamReader file = File.OpenText(@"..\..\..\GasLibrary\docs\GasPrices.txt"))
            {
                // While file has not reached the end
                while (!file.EndOfStream)
                {
                    // Get month, day, year:price
                    string[] month_day = file.ReadLine().Split('-');

                    // Get year, price
                    string[] year_price = month_day[2].Split(':');

                    // Create GasInfo
                    GasInfo gasinfo = new GasInfo(
                        int.Parse(year_price[0]),       // Get Year
                        int.Parse(month_day[0]),        // Get Month
                        int.Parse(month_day[1]),        // Get Day
                        decimal.Parse(year_price[1]));  // Get Price

                    // Add info to list
                    allGasInfo.Add(gasinfo);
                }
            }
        }
    }
}
