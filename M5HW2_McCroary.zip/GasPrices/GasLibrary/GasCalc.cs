﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GasLibrary
{
    public static class GasCalc
    {
        public static void PerYear()
        {
            // Cycle through every year
            for (int i = GasReader.allGasInfo.Min(item => item.Time.Year); i <= GasReader.allGasInfo.Max(item => item.Time.Year); i++)
            {
                // Get all pricest in that year
                var pricesPerYear = from info in GasReader.allGasInfo
                                    where info.Time.Year == i
                                    orderby info.Price
                                    select info;

                // Calculate Average
                GasReader.avgPricePerYear.Add(i, pricesPerYear.Sum(item => item.Price) / pricesPerYear.Count());

                // Get info with Highest and Lowest prices
                GasInfo[] high_low = { pricesPerYear.Last(), pricesPerYear.First() };
                GasReader.highLowPerYear.Add(i, high_low);
            }
        }

        public static void PerMonth()
        {
            // Cycle through every month
            for (int i = GasReader.allGasInfo.Min(item => item.Time.Month); i <= GasReader.allGasInfo.Max(item => item.Time.Month); i++)
            {
                // Get all pricest in that month
                var pricesPerMonth = from info in GasReader.allGasInfo
                                     where info.Time.Month == i
                                     orderby info.Price
                                     select info;

                // Calculate Average
                GasReader.avgPricePerMonth.Add(i, pricesPerMonth.Sum(item => item.Price) / pricesPerMonth.Count());
            }
        }
    }
}
