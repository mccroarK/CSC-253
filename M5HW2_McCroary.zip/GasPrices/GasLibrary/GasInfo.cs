﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GasLibrary
{
    public class GasInfo
    {
        // Properties
        public DateTime Time { get; set; }
        public decimal Price { get; set; }

        // Constructors
        public GasInfo()
        {
            Time = new DateTime();
            Price = 0m;
        }

        public GasInfo(int year, int month, int day, decimal price)
        {
            Time = new DateTime(year, month, day);
            Price = price;
        }
    }
}
