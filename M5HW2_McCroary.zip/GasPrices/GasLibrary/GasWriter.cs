﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace GasLibrary
{
    public static class GasWriter
    {
        public static void Run()
        {
            // Write lowest to highest file
            using (StreamWriter low_to_high = File.CreateText(@"..\..\docs\low-to-high.txt"))
            {
                // Get GasInfo list sorted from lowest to high
                var prices_to_highest = from info in GasReader.allGasInfo
                                        orderby info.Price
                                        select info;

                // For each entry in the lowest to highest price
                foreach (GasInfo info in prices_to_highest)
                {
                    low_to_high.WriteLine($"{info.Time.Month}-{info.Time.Day}-{info.Time.Year}: {info.Price}");
                }
            }

            // Write highest to lowest file
            using (StreamWriter high_to_low = File.CreateText(@"..\..\docs\high-to-low.txt"))
            {
                // Get GasInfo list sorted from highest to low
                var prices_to_highest = from info in GasReader.allGasInfo
                                        orderby info.Price descending
                                        select info;

                // For each entry in the highest to lowest price
                foreach (GasInfo info in prices_to_highest)
                {
                    high_to_low.WriteLine($"{info.Time.Month}-{info.Time.Day}-{info.Time.Year}: {info.Price}");
                }
            }
        }
    }
}
