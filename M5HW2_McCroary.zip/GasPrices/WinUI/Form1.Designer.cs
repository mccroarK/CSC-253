﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titleLabel = new System.Windows.Forms.Label();
            this.avgperyearButton = new System.Windows.Forms.Button();
            this.avgpermonthButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.highestlowestButton = new System.Windows.Forms.Button();
            this.buttonPanel = new System.Windows.Forms.Panel();
            this.infoLabel = new System.Windows.Forms.Label();
            this.buttonPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(112, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(117, 25);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Gas Prices";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // avgperyearButton
            // 
            this.avgperyearButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.avgperyearButton.Location = new System.Drawing.Point(3, 3);
            this.avgperyearButton.Name = "avgperyearButton";
            this.avgperyearButton.Size = new System.Drawing.Size(197, 27);
            this.avgperyearButton.TabIndex = 0;
            this.avgperyearButton.Text = "Average Per Year";
            this.avgperyearButton.UseVisualStyleBackColor = true;
            this.avgperyearButton.Click += new System.EventHandler(this.avgperyearButton_Click);
            // 
            // avgpermonthButton
            // 
            this.avgpermonthButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.avgpermonthButton.Location = new System.Drawing.Point(3, 36);
            this.avgpermonthButton.Name = "avgpermonthButton";
            this.avgpermonthButton.Size = new System.Drawing.Size(197, 27);
            this.avgpermonthButton.TabIndex = 1;
            this.avgpermonthButton.Text = "Average Per Month";
            this.avgpermonthButton.UseVisualStyleBackColor = true;
            this.avgpermonthButton.Click += new System.EventHandler(this.avgpermonthButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(274, 187);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // highestlowestButton
            // 
            this.highestlowestButton.Location = new System.Drawing.Point(3, 69);
            this.highestlowestButton.Name = "highestlowestButton";
            this.highestlowestButton.Size = new System.Drawing.Size(197, 27);
            this.highestlowestButton.TabIndex = 2;
            this.highestlowestButton.Text = "Highest / Lowest Per Year";
            this.highestlowestButton.UseVisualStyleBackColor = true;
            this.highestlowestButton.Click += new System.EventHandler(this.highestlowestButton_Click);
            // 
            // buttonPanel
            // 
            this.buttonPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.buttonPanel.Controls.Add(this.highestlowestButton);
            this.buttonPanel.Controls.Add(this.avgpermonthButton);
            this.buttonPanel.Controls.Add(this.avgperyearButton);
            this.buttonPanel.Location = new System.Drawing.Point(69, 77);
            this.buttonPanel.Name = "buttonPanel";
            this.buttonPanel.Size = new System.Drawing.Size(203, 102);
            this.buttonPanel.TabIndex = 0;
            // 
            // infoLabel
            // 
            this.infoLabel.Location = new System.Drawing.Point(12, 34);
            this.infoLabel.Name = "infoLabel";
            this.infoLabel.Size = new System.Drawing.Size(337, 40);
            this.infoLabel.TabIndex = 6;
            this.infoLabel.Text = "Displays information from the GasPrices.txt and produces two txt files in the Win" +
    "UI/docs directory.";
            this.infoLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AcceptButton = this.avgperyearButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(361, 222);
            this.Controls.Add(this.infoLabel);
            this.Controls.Add(this.buttonPanel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.titleLabel);
            this.Name = "Form1";
            this.Text = "Gas Prices";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.buttonPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Button avgperyearButton;
        private System.Windows.Forms.Button avgpermonthButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button highestlowestButton;
        private System.Windows.Forms.Panel buttonPanel;
        private System.Windows.Forms.Label infoLabel;
    }
}

