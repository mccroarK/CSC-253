﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GasLibrary;

/*
* 11/19/2023
* CSC 253
* Kevin McCroary
* Reads the gas prices txt file to display information about price averages and sorted lists.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Run Gas Reader
            GasReader.Run();
            GasCalc.PerYear();
            GasCalc.PerMonth();
            GasWriter.Run();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close app
            Close();
        }

        private void avgperyearButton_Click(object sender, EventArgs e)
        {
            // Create display string
            string display_string = "";

            // Fill display string
            foreach(var year in GasReader.avgPricePerYear)
            {
                display_string += $"{year.Key}: {year.Value.ToString("c")}\n";
            }

            // Display average prices per year
            MessageBox.Show(display_string);
        }

        private void highestlowestButton_Click(object sender, EventArgs e)
        {
            // Create display string
            string display_string = "";

            // Fill display string
            foreach (var year in GasReader.highLowPerYear)
            {
                display_string += $"{year.Key}:\n" +
                    $"\t{year.Value[0].Time.Month}-{year.Value[0].Time.Day}: {year.Value[0].Price.ToString("c")}" +
                    $"\t{year.Value[1].Time.Month}-{year.Value[1].Time.Day}: {year.Value[1].Price.ToString("c")}\n";
            }

            // Display highest and lowest price per year
            MessageBox.Show(display_string);
        }

        private void avgpermonthButton_Click(object sender, EventArgs e)
        {
            // Create display string
            string display_string = "";

            // Fill display string
            foreach (var month in GasReader.avgPricePerMonth)
            {
                display_string += $"{month.Key}: {month.Value.ToString("c")}\n";
            }

            // Display average prices per month
            MessageBox.Show(display_string);
        }
    }
}
