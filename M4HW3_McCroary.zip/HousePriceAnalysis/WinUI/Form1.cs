﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HouseLibrary;

/**
* 10/22/2023
* CSC 253
* Kevin McCroary
* Allows user to sort through house information using ranges of price, bedroom count, bathroom count, and square footage.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close app
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Load the houses
            LoadHouses.Run();

            // Create a list for the house info
            List<string> houseInfoList = new List<string>();

            // Get the house info
            LoadHouses.houseList.ForEach(x => houseInfoList.Add(x.GetInfo()));

            // Change the list box data source to the house info list
            houseListBox.DataSource = houseInfoList;
        }

        private void filterButton_Click(object sender, EventArgs e)
        {
            // Create initial list of houses and info
            List<House> houseList = LoadHouses.houseList;
            List<string> houseInfoList = new List<string>();

            // Create empty error string
            string errorstr = "";

            // Try to filter price
            try
            {
                houseList = Filter.Price(
                    houseList,
                    int.Parse(priceMinTextBox.Text),
                    int.Parse(priceMaxTextBox.Text));
            }
            // Catch error
            catch (Exception error)
            {
                // If price min/max textboxes are incorrect and not empty
                if (!(priceMinTextBox.Text == "" && priceMaxTextBox.Text == ""))
                {
                    // Add error message to error string
                    errorstr += $"Price:\t\t{error.Message}\n";
                }
            }

            // Try to filter bedrooms
            try
            {
                houseList = Filter.Bedrooms(
                    houseList,
                    int.Parse(bedrmMinTextBox.Text),
                    int.Parse(bedrmMaxTextBox.Text));
            }
            // Catch error
            catch (Exception error)
            {
                // If bedroom min/max textboxes are incorrect and not empty
                if (!(bedrmMinTextBox.Text == "" && bedrmMaxTextBox.Text == ""))
                {
                    // Add error message to error string
                    errorstr += $"Bedrooms:\t{error.Message}\n";
                }
            }
            
            // Try to filter bathrooms
            try
            {
                houseList = Filter.Bathrooms(
                    houseList,
                    double.Parse(bathrmMinTextBox.Text),
                    double.Parse(bathrmMaxTextBox.Text));
            }
            // Catch error
            catch (Exception error)
            {
                // If bathroom min/max textboxes are incorrect and not empty
                if (!(bathrmMinTextBox.Text == "" && bathrmMaxTextBox.Text == ""))
                {
                    // Add error message to error string
                    errorstr += $"Bathrooms:\t{error.Message}\n";
                }
            }
            
            // Try to filter square footage
            try
            {
                houseList = Filter.SquareFeet(
                    houseList,
                    int.Parse(sqrftMinTextBox.Text),
                    int.Parse(sqrftMaxTextBox.Text));
            }
            // Catch error
            catch (Exception error)
            {
                // If square footage min/max textboxes are incorrect and not empty
                if (!(sqrftMinTextBox.Text == "" && sqrftMaxTextBox.Text == ""))
                {
                    // Add error message to error string
                    errorstr += $"Square Feet:\t{error.Message}";
                }
            }

            // Display error string if it is not empty
            if (errorstr != "")
            {
                MessageBox.Show(errorstr);
            }

            // Get house information
            houseList.ForEach(x => houseInfoList.Add(x.GetInfo()));

            // Display house information
            houseListBox.DataSource = houseInfoList;
        }
    }
}
