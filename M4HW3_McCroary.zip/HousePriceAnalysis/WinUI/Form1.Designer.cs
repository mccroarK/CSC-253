﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.priceLabel = new System.Windows.Forms.Label();
            this.bedroomLabel = new System.Windows.Forms.Label();
            this.bathroomLabel = new System.Windows.Forms.Label();
            this.squarefeetLabel = new System.Windows.Forms.Label();
            this.minLabel = new System.Windows.Forms.Label();
            this.priceMinTextBox = new System.Windows.Forms.TextBox();
            this.priceMaxTextBox = new System.Windows.Forms.TextBox();
            this.maxLabel = new System.Windows.Forms.Label();
            this.bedrmMaxTextBox = new System.Windows.Forms.TextBox();
            this.bedrmMinTextBox = new System.Windows.Forms.TextBox();
            this.bathrmMaxTextBox = new System.Windows.Forms.TextBox();
            this.bathrmMinTextBox = new System.Windows.Forms.TextBox();
            this.sqrftMaxTextBox = new System.Windows.Forms.TextBox();
            this.sqrftMinTextBox = new System.Windows.Forms.TextBox();
            this.filterButton = new System.Windows.Forms.Button();
            this.titleLabel = new System.Windows.Forms.Label();
            this.instructLabel = new System.Windows.Forms.Label();
            this.houseListBox = new System.Windows.Forms.ListBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.filterButton);
            this.panel1.Controls.Add(this.sqrftMaxTextBox);
            this.panel1.Controls.Add(this.sqrftMinTextBox);
            this.panel1.Controls.Add(this.bathrmMaxTextBox);
            this.panel1.Controls.Add(this.bathrmMinTextBox);
            this.panel1.Controls.Add(this.bedrmMaxTextBox);
            this.panel1.Controls.Add(this.bedrmMinTextBox);
            this.panel1.Controls.Add(this.priceMaxTextBox);
            this.panel1.Controls.Add(this.maxLabel);
            this.panel1.Controls.Add(this.priceMinTextBox);
            this.panel1.Controls.Add(this.minLabel);
            this.panel1.Controls.Add(this.squarefeetLabel);
            this.panel1.Controls.Add(this.bathroomLabel);
            this.panel1.Controls.Add(this.bedroomLabel);
            this.panel1.Controls.Add(this.priceLabel);
            this.panel1.Location = new System.Drawing.Point(12, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(329, 163);
            this.panel1.TabIndex = 0;
            // 
            // priceLabel
            // 
            this.priceLabel.Location = new System.Drawing.Point(3, 39);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(100, 23);
            this.priceLabel.TabIndex = 0;
            this.priceLabel.Text = "Price:";
            this.priceLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // bedroomLabel
            // 
            this.bedroomLabel.Location = new System.Drawing.Point(3, 62);
            this.bedroomLabel.Name = "bedroomLabel";
            this.bedroomLabel.Size = new System.Drawing.Size(100, 23);
            this.bedroomLabel.TabIndex = 1;
            this.bedroomLabel.Text = "Bedrooms:";
            this.bedroomLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // bathroomLabel
            // 
            this.bathroomLabel.Location = new System.Drawing.Point(3, 85);
            this.bathroomLabel.Name = "bathroomLabel";
            this.bathroomLabel.Size = new System.Drawing.Size(100, 23);
            this.bathroomLabel.TabIndex = 2;
            this.bathroomLabel.Text = "Bathrooms:";
            this.bathroomLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // squarefeetLabel
            // 
            this.squarefeetLabel.Location = new System.Drawing.Point(3, 108);
            this.squarefeetLabel.Name = "squarefeetLabel";
            this.squarefeetLabel.Size = new System.Drawing.Size(100, 23);
            this.squarefeetLabel.TabIndex = 3;
            this.squarefeetLabel.Text = "Square Feet:";
            this.squarefeetLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // minLabel
            // 
            this.minLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minLabel.Location = new System.Drawing.Point(109, 9);
            this.minLabel.Name = "minLabel";
            this.minLabel.Size = new System.Drawing.Size(100, 24);
            this.minLabel.TabIndex = 4;
            this.minLabel.Text = "Min";
            this.minLabel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // priceMinTextBox
            // 
            this.priceMinTextBox.Location = new System.Drawing.Point(109, 36);
            this.priceMinTextBox.Name = "priceMinTextBox";
            this.priceMinTextBox.Size = new System.Drawing.Size(100, 22);
            this.priceMinTextBox.TabIndex = 0;
            // 
            // priceMaxTextBox
            // 
            this.priceMaxTextBox.Location = new System.Drawing.Point(215, 36);
            this.priceMaxTextBox.Name = "priceMaxTextBox";
            this.priceMaxTextBox.Size = new System.Drawing.Size(100, 22);
            this.priceMaxTextBox.TabIndex = 1;
            // 
            // maxLabel
            // 
            this.maxLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maxLabel.Location = new System.Drawing.Point(215, 9);
            this.maxLabel.Name = "maxLabel";
            this.maxLabel.Size = new System.Drawing.Size(100, 24);
            this.maxLabel.TabIndex = 7;
            this.maxLabel.Text = "Max";
            this.maxLabel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // bedrmMaxTextBox
            // 
            this.bedrmMaxTextBox.Location = new System.Drawing.Point(215, 59);
            this.bedrmMaxTextBox.Name = "bedrmMaxTextBox";
            this.bedrmMaxTextBox.Size = new System.Drawing.Size(100, 22);
            this.bedrmMaxTextBox.TabIndex = 3;
            // 
            // bedrmMinTextBox
            // 
            this.bedrmMinTextBox.Location = new System.Drawing.Point(109, 59);
            this.bedrmMinTextBox.Name = "bedrmMinTextBox";
            this.bedrmMinTextBox.Size = new System.Drawing.Size(100, 22);
            this.bedrmMinTextBox.TabIndex = 2;
            // 
            // bathrmMaxTextBox
            // 
            this.bathrmMaxTextBox.Location = new System.Drawing.Point(215, 82);
            this.bathrmMaxTextBox.Name = "bathrmMaxTextBox";
            this.bathrmMaxTextBox.Size = new System.Drawing.Size(100, 22);
            this.bathrmMaxTextBox.TabIndex = 5;
            // 
            // bathrmMinTextBox
            // 
            this.bathrmMinTextBox.Location = new System.Drawing.Point(109, 82);
            this.bathrmMinTextBox.Name = "bathrmMinTextBox";
            this.bathrmMinTextBox.Size = new System.Drawing.Size(100, 22);
            this.bathrmMinTextBox.TabIndex = 4;
            // 
            // sqrftMaxTextBox
            // 
            this.sqrftMaxTextBox.Location = new System.Drawing.Point(215, 105);
            this.sqrftMaxTextBox.Name = "sqrftMaxTextBox";
            this.sqrftMaxTextBox.Size = new System.Drawing.Size(100, 22);
            this.sqrftMaxTextBox.TabIndex = 7;
            // 
            // sqrftMinTextBox
            // 
            this.sqrftMinTextBox.Location = new System.Drawing.Point(109, 105);
            this.sqrftMinTextBox.Name = "sqrftMinTextBox";
            this.sqrftMinTextBox.Size = new System.Drawing.Size(100, 22);
            this.sqrftMinTextBox.TabIndex = 6;
            // 
            // filterButton
            // 
            this.filterButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.filterButton.Location = new System.Drawing.Point(240, 133);
            this.filterButton.Name = "filterButton";
            this.filterButton.Size = new System.Drawing.Size(75, 23);
            this.filterButton.TabIndex = 8;
            this.filterButton.Text = "Filter";
            this.filterButton.UseVisualStyleBackColor = true;
            this.filterButton.Click += new System.EventHandler(this.filterButton_Click);
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(47, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(259, 29);
            this.titleLabel.TabIndex = 1;
            this.titleLabel.Text = "House Price Analysis";
            // 
            // instructLabel
            // 
            this.instructLabel.Location = new System.Drawing.Point(12, 38);
            this.instructLabel.Name = "instructLabel";
            this.instructLabel.Size = new System.Drawing.Size(329, 36);
            this.instructLabel.TabIndex = 2;
            this.instructLabel.Text = "List house information using ranges of price, bedroom count, bathroom count, and " +
    "square footage.";
            this.instructLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // houseListBox
            // 
            this.houseListBox.FormattingEnabled = true;
            this.houseListBox.ItemHeight = 16;
            this.houseListBox.Location = new System.Drawing.Point(12, 252);
            this.houseListBox.Name = "houseListBox";
            this.houseListBox.Size = new System.Drawing.Size(329, 148);
            this.houseListBox.TabIndex = 3;
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(266, 415);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.filterButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(356, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.houseListBox);
            this.Controls.Add(this.instructLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "House Price Analysis";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label squarefeetLabel;
        private System.Windows.Forms.Label bathroomLabel;
        private System.Windows.Forms.Label bedroomLabel;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.TextBox sqrftMaxTextBox;
        private System.Windows.Forms.TextBox sqrftMinTextBox;
        private System.Windows.Forms.TextBox bathrmMaxTextBox;
        private System.Windows.Forms.TextBox bathrmMinTextBox;
        private System.Windows.Forms.TextBox bedrmMaxTextBox;
        private System.Windows.Forms.TextBox bedrmMinTextBox;
        private System.Windows.Forms.TextBox priceMaxTextBox;
        private System.Windows.Forms.Label maxLabel;
        private System.Windows.Forms.TextBox priceMinTextBox;
        private System.Windows.Forms.Label minLabel;
        private System.Windows.Forms.Button filterButton;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label instructLabel;
        private System.Windows.Forms.ListBox houseListBox;
        private System.Windows.Forms.Button exitButton;
    }
}

