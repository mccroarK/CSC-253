﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseLibrary
{
    public class House
    {
        #region Properties
        public int Price { get; set; }
        public int Bedrooms { get; set; }
        public double Bathrooms { get; set; }
        public int SquareFeet { get; set; }
        #endregion
        #region Constructors
        public House()
        {
            // Default Constructor
            Price = 0;
            Bedrooms = 0;
            Bathrooms = 0f;
            SquareFeet = 0;
        }

        public House(int price, int bedrms, double bathrms, int sqrft)
        {
            // Constructor
            Price = price;
            Bedrooms = bedrms;
            Bathrooms = bathrms;
            SquareFeet = sqrft;
        }
        #endregion
        #region Methods
        public string GetInfo()
        {
            // Return house info
            return
                $"${Price}   \t" +
                $"{Bedrooms}\t" +
                $"{Bathrooms}\t" +
                $"{SquareFeet}";
        }
        #endregion
    }
}
