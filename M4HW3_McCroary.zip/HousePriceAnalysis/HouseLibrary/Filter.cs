﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HouseLibrary
{
    public static class Filter
    {
        public static List<House> Price(List<House> inputList, int min, int max)
        {
            // Filter list by price and return
            return inputList.FindAll(x => min <= x.Price && x.Price <= max);
        }

        public static List<House> Bedrooms(List<House> inputList, int min, int max)
        {
            // Filter list by bedrooms and return
            return inputList.FindAll(x => min <= x.Bedrooms && x.Bedrooms <= max);
        }

        public static List<House> Bathrooms(List<House> inputList, double min, double max)
        {
            // Filter list by bathrooms and return
            return inputList.FindAll(x => min <= x.Bathrooms && x.Bathrooms <= max);
        }

        public static List<House> SquareFeet(List<House> inputList, int min, int max)
        {
            // Filter list by square feet and return
            return inputList.FindAll(x => min <= x.SquareFeet && x.SquareFeet <= max);
        }
    }
}
