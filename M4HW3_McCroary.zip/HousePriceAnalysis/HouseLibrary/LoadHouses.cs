﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HouseLibrary
{
    public static class LoadHouses
    {
        // List of all houses
        public static List<House> houseList = new List<House>();

        public static void Run()
        {
            // Load house file
            using (StreamReader reader = File.OpenText(@"..\..\..\HouseLibrary\Docs\house_prices.csv"))
            {
                // While file has not ended
                while (!reader.EndOfStream)
                {
                    // Split csv lines into tokens by commas
                    string[] tokens = reader.ReadLine().Split(',');

                    // Create a house using the tokens
                    House house = new House(
                        int.Parse(tokens[0]),
                        int.Parse(tokens[1]),
                        double.Parse(tokens[2]),
                        int.Parse(tokens[3]));

                    // Enter the house info into the house list
                    houseList.Add(house);
                }
            }
        }
    }
}
