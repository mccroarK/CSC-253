﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PetLibrary;
namespace WpfUI

/**
* 12/15/2023
* CSC 253
* Kevin McCroary
* Allows a user to input pet data to create an instance of a pet class and displays that class information.
*/

{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void submitBTN_Click(object sender, RoutedEventArgs e)
        {
            // Try to create pet
            try
            {
                // Create object using textbox input
                Pet pet = new Pet(nameTB.Text, typeTB.Text, int.Parse(ageTB.Text));

                // Show pet info
                MessageBox.Show(pet.ToString());
            }

            // Catch errors
            catch (Exception ex)
            {
                // Print error message
                MessageBox.Show(ex.Message);
            }
        }

        private void closeBTN_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
