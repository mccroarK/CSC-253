﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetLibrary
{
    public class Pet
    {
        // Properties
        public string Name { get; set; }
        public string Type { get; set; }
        public int Age { get; set; }


        // Constructors
        public Pet()
        {
            Name = "";
            Type = "";
            Age = 0;
        }

        public Pet(string name, string type, int age)
        {
            Name = name;
            Type = type;
            Age = age;
        }

        // Methods
        public override string ToString()
        {
            return $"{Name}\nType: {Type}\nAge: {Age}";
        }
    }
}
