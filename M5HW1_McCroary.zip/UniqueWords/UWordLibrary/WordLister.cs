﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace UWordLibrary
{
    public static class WordLister
    {
        public static IEnumerable<string> Run(string filename)
        {
            // Create empty word list
            List<string> allwords = new List<string>();

            // Use the file
            using (StreamReader file = File.OpenText(filename))
            {
                // While the file has not ended
                while (!file.EndOfStream)
                {
                    // Read a line and split into words
                    string[] words = file.ReadLine().Split();

                    // Add words to the list
                    foreach(string word in words)
                    {
                        allwords.Add(word);
                    }
                }
            }

            // Get distinct words from all words
            var uniquewords = allwords.Distinct();

            // Return the unique word list
            return uniquewords;
        }
    }
}
