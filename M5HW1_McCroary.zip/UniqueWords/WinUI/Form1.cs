﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UWordLibrary;

/*
* 11/19/2023
* CSC 253
* Kevin McCroary
* Returns unique words from a specified file
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the app
            Close();
        }

        private void fileButton_Click(object sender, EventArgs e)
        {
            // Try
            try
            {
                // Open a file
                if (openDialog.ShowDialog() == DialogResult.OK)
                {
                    // Send file name over to class library and return unique words list
                    var words = WordLister.Run(openDialog.FileName);

                    // Add unique words to list box items
                    foreach (string word in words)
                    {
                        wordListBox.Items.Add(word);
                    }
                }
            }

            // Catch errors
            catch (Exception error)
            {
                // Show error message
                MessageBox.Show(error.Message);
            }
        }
    }
}
