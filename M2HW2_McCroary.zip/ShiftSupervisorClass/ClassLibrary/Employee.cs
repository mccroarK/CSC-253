﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Employee
    {
        // Default Constructor
        public Employee()
        {
            Name = "";
            Number = 0;
        }

        // Properties
        public string Name { get; set; }
        public int Number { get; set; }
    }
}
