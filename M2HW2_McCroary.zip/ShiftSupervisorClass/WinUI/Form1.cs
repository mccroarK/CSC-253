﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;

/*
* 9/24/2023
* CSC 253
* Kevin McCroary
* Creates an employee class and an extension of it called the shiftsupervisor class
*/

namespace WinUI
{
    public partial class shiftSupervisorForm : Form
    {
        public shiftSupervisorForm()
        {
            InitializeComponent();
        }

        private void employeeButton_Click(object sender, EventArgs e)
        {
            // Create employee instance
            Employee employee = new Employee();

            // Initialize info variables
            int num;

            // Try to enter in information
            employee.Name = nameTextBox.Text;

            if (int.TryParse(numberTextBox.Text, out num))
            {
                employee.Number = num;
            }

            // Display employee
            MessageBox.Show(
                $"Employee\n" +
                $"Name:\t\t{employee.Name}\n" +
                $"Number:\t\t{employee.Number}");
        }

        private void shiftSupervisorButton_Click(object sender, EventArgs e)
        {
            // Create shiftsupervisor instance
            ShiftSupervisor supervisor = new ShiftSupervisor();

            // Initialize info variables
            int num;
            decimal salary;
            decimal bonus;

            // Try to enter in information
            supervisor.Name = nameTextBox.Text;

            if (int.TryParse(numberTextBox.Text, out num))
            {
                // Enter number
                supervisor.Number = num;
            }

            if (decimal.TryParse(salaryTextBox.Text, out salary))
            {
                // Enter salary
                supervisor.Salary = salary;
            }

            if (decimal.TryParse(bonusTextBox.Text, out bonus))
            {
                // Enter bonus
                supervisor.Bonus = bonus;
            }

            // Display supervisor
            MessageBox.Show(
                $"Shift Supervisor\n" +
                $"Name:\t\t{supervisor.Name}\n" +
                $"Number:\t\t{supervisor.Number}\n" +
                $"Annual Salary:\t{supervisor.Salary.ToString("c")}\n" +
                $"Annual Bonus:\t{supervisor.Bonus.ToString("c")}");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the program
            Close();
        }
    }
}
