﻿
namespace WinUI
{
    partial class shiftSupervisorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employeeButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.helpLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.shiftSupervisorGroupBox = new System.Windows.Forms.GroupBox();
            this.bonusTextBox = new System.Windows.Forms.TextBox();
            this.salaryTextBox = new System.Windows.Forms.TextBox();
            this.bonusLabel = new System.Windows.Forms.Label();
            this.salaryLabel = new System.Windows.Forms.Label();
            this.employeeGroupBox = new System.Windows.Forms.GroupBox();
            this.numberTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.number = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.shiftSupervisorButton = new System.Windows.Forms.Button();
            this.shiftSupervisorGroupBox.SuspendLayout();
            this.employeeGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // employeeButton
            // 
            this.employeeButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.employeeButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.employeeButton.Location = new System.Drawing.Point(163, 214);
            this.employeeButton.Name = "employeeButton";
            this.employeeButton.Size = new System.Drawing.Size(108, 44);
            this.employeeButton.TabIndex = 2;
            this.employeeButton.Text = "Create Employee";
            this.employeeButton.UseVisualStyleBackColor = true;
            this.employeeButton.Click += new System.EventHandler(this.employeeButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(464, 294);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // helpLabel
            // 
            this.helpLabel.Location = new System.Drawing.Point(85, 57);
            this.helpLabel.Name = "helpLabel";
            this.helpLabel.Size = new System.Drawing.Size(383, 40);
            this.helpLabel.TabIndex = 11;
            this.helpLabel.Text = "Fill in employee and shift supervisor properties to create an instance of an Empl" +
    "oyee or ShiftSupervisor class.";
            this.helpLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.Location = new System.Drawing.Point(141, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(270, 29);
            this.titleLabel.TabIndex = 10;
            this.titleLabel.Text = "Shift Supervisor Class";
            // 
            // shiftSupervisorGroupBox
            // 
            this.shiftSupervisorGroupBox.Controls.Add(this.bonusTextBox);
            this.shiftSupervisorGroupBox.Controls.Add(this.salaryTextBox);
            this.shiftSupervisorGroupBox.Controls.Add(this.bonusLabel);
            this.shiftSupervisorGroupBox.Controls.Add(this.salaryLabel);
            this.shiftSupervisorGroupBox.Location = new System.Drawing.Point(277, 123);
            this.shiftSupervisorGroupBox.Name = "shiftSupervisorGroupBox";
            this.shiftSupervisorGroupBox.Size = new System.Drawing.Size(259, 85);
            this.shiftSupervisorGroupBox.TabIndex = 1;
            this.shiftSupervisorGroupBox.TabStop = false;
            this.shiftSupervisorGroupBox.Text = "Shift Supervisor Properties";
            // 
            // bonusTextBox
            // 
            this.bonusTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bonusTextBox.Location = new System.Drawing.Point(112, 50);
            this.bonusTextBox.Name = "bonusTextBox";
            this.bonusTextBox.Size = new System.Drawing.Size(141, 22);
            this.bonusTextBox.TabIndex = 1;
            // 
            // salaryTextBox
            // 
            this.salaryTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salaryTextBox.Location = new System.Drawing.Point(112, 27);
            this.salaryTextBox.Name = "salaryTextBox";
            this.salaryTextBox.Size = new System.Drawing.Size(141, 22);
            this.salaryTextBox.TabIndex = 0;
            // 
            // bonusLabel
            // 
            this.bonusLabel.Location = new System.Drawing.Point(6, 52);
            this.bonusLabel.Name = "bonusLabel";
            this.bonusLabel.Size = new System.Drawing.Size(100, 23);
            this.bonusLabel.TabIndex = 3;
            this.bonusLabel.Text = "Annual Bonus:";
            this.bonusLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // salaryLabel
            // 
            this.salaryLabel.Location = new System.Drawing.Point(6, 29);
            this.salaryLabel.Name = "salaryLabel";
            this.salaryLabel.Size = new System.Drawing.Size(100, 23);
            this.salaryLabel.TabIndex = 2;
            this.salaryLabel.Text = "Annual Salary:";
            this.salaryLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // employeeGroupBox
            // 
            this.employeeGroupBox.Controls.Add(this.numberTextBox);
            this.employeeGroupBox.Controls.Add(this.nameTextBox);
            this.employeeGroupBox.Controls.Add(this.number);
            this.employeeGroupBox.Controls.Add(this.nameLabel);
            this.employeeGroupBox.Location = new System.Drawing.Point(12, 123);
            this.employeeGroupBox.Name = "employeeGroupBox";
            this.employeeGroupBox.Size = new System.Drawing.Size(259, 85);
            this.employeeGroupBox.TabIndex = 0;
            this.employeeGroupBox.TabStop = false;
            this.employeeGroupBox.Text = "Employee Properties";
            // 
            // numberTextBox
            // 
            this.numberTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numberTextBox.Location = new System.Drawing.Point(112, 49);
            this.numberTextBox.Name = "numberTextBox";
            this.numberTextBox.Size = new System.Drawing.Size(141, 22);
            this.numberTextBox.TabIndex = 1;
            // 
            // nameTextBox
            // 
            this.nameTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameTextBox.Location = new System.Drawing.Point(112, 26);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(141, 22);
            this.nameTextBox.TabIndex = 0;
            // 
            // number
            // 
            this.number.Location = new System.Drawing.Point(6, 51);
            this.number.Name = "number";
            this.number.Size = new System.Drawing.Size(100, 23);
            this.number.TabIndex = 1;
            this.number.Text = "Number:";
            this.number.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // nameLabel
            // 
            this.nameLabel.Location = new System.Drawing.Point(6, 28);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(100, 23);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name:";
            this.nameLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // shiftSupervisorButton
            // 
            this.shiftSupervisorButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.shiftSupervisorButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.shiftSupervisorButton.Location = new System.Drawing.Point(428, 214);
            this.shiftSupervisorButton.Name = "shiftSupervisorButton";
            this.shiftSupervisorButton.Size = new System.Drawing.Size(108, 44);
            this.shiftSupervisorButton.TabIndex = 3;
            this.shiftSupervisorButton.Text = "Create Shift Supervisor";
            this.shiftSupervisorButton.UseVisualStyleBackColor = true;
            this.shiftSupervisorButton.Click += new System.EventHandler(this.shiftSupervisorButton_Click);
            // 
            // shiftSupervisorForm
            // 
            this.AcceptButton = this.employeeButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(551, 329);
            this.Controls.Add(this.shiftSupervisorButton);
            this.Controls.Add(this.employeeButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.helpLabel);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.shiftSupervisorGroupBox);
            this.Controls.Add(this.employeeGroupBox);
            this.Name = "shiftSupervisorForm";
            this.Text = "Shift Supervisor Class";
            this.shiftSupervisorGroupBox.ResumeLayout(false);
            this.shiftSupervisorGroupBox.PerformLayout();
            this.employeeGroupBox.ResumeLayout(false);
            this.employeeGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button employeeButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label helpLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.GroupBox shiftSupervisorGroupBox;
        private System.Windows.Forms.TextBox bonusTextBox;
        private System.Windows.Forms.TextBox salaryTextBox;
        private System.Windows.Forms.Label bonusLabel;
        private System.Windows.Forms.Label salaryLabel;
        private System.Windows.Forms.GroupBox employeeGroupBox;
        private System.Windows.Forms.TextBox numberTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label number;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Button shiftSupervisorButton;
    }
}

