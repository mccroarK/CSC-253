﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FuncLibrary
{
    public static class FileHandler
    {
        public static StreamReader inputFile;
        public static StreamWriter outputFile;

        public static void OpenFile(string filename)
        {
            // Open input file
            inputFile = File.OpenText(filename);
        }

        public static void SaveFile(string filename)
        {
            // Save output file
            outputFile = File.CreateText(filename);
        }

        public static void CloseFiles()
        {
            // Close input and output files
            inputFile.Close();
            outputFile.Close();
        }

        public static void DictToFile(Dictionary<string, List<int>> dict)
        {
            // Iterate through KeyValuePairs
            foreach(KeyValuePair<string, List<int>> entry in dict)
            {
                // Write Key to file
                outputFile.Write($"{entry.Key}: ");

                // Write Values to file
                foreach(int value in entry.Value)
                {
                    outputFile.Write(value + " ");
                }

                // End line
                outputFile.WriteLine();
            }
        }
    }
}
