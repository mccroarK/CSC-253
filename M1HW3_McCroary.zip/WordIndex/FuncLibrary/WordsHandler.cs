﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FuncLibrary
{
    public static class WordsHandler
    {
        public static Dictionary<string, List<int>> ToDict(StreamReader input)
        {
            // Create Dictionary and Sorted Dictionary
            var dict = new Dictionary<string, List<int>>();
            
            // Read the file
            using (input)
            {
                // Set the line index to 0
                int lineNum = 0;

                // Create list of words
                List<string> list = new List<string>();

                // While the file has not reached the end
                while (!input.EndOfStream)
                {
                    // Add to line index
                    lineNum++;

                    // Split the line and place words into a variable
                    string[] words = input.ReadLine().Split(' ');

                    // Iterate through words
                    foreach (string word in words)
                    {
                        // If word is not a key
                        if (!dict.ContainsKey(word))
                        {
                            // Create a dictionary entry with List
                            dict[word] = new List<int>();
                        }

                        // If line number is not in word pair
                        if (!dict[word].Contains(lineNum))
                        {
                            // Add line number to word key pair
                            dict[word].Add(lineNum);
                        }
                    }
                }
            }
            // Return Dictionary
            return dict;
        }

        public static Dictionary<string, List<int>> SortDict(Dictionary<string, List<int>> dict)
        {
            // Create Sorted Dictionary
            var sortedDict = new Dictionary<string, List<int>>();

            // Create array of keys to sort
            string[] keys = new string[dict.Count];

            // Add dict keys to array of keys
            dict.Keys.CopyTo(keys, 0);

            // Initialize sorting variables
            int minIndex;
            string minWord;

            // Loop through every element except last one
            for (int i = 0; i < keys.Length - 1; i++)
            {
                // Assume first word is smallest
                minIndex = 0;
                minWord = keys[minIndex];

                // Scan the array starting at the second index
                for (int j = i + 1; j < keys.Length; j++)
                {
                    // Compare the word in index 0 to the current word
                    if (string.Compare(keys[j], minWord, true) < 0)
                    {
                        // New minimum word is chosen
                        minIndex = j;
                        minWord = keys[j];
                    }
                }

                // Swap the words
                Swap(ref keys[minIndex], ref keys[i]);
            }

            // Fill Sorted Dictionary
            foreach (string key in keys)
            {
                sortedDict[key] = dict[key];
            }
            // Wish I could use Array.Sort but I don't think book mentions that
            // Return Sorted Dictionary
            return sortedDict;
        }

        public static void Swap(ref string a, ref string b)
        {
            string temp = a;
            a = b;
            b = temp;
        }
    }
}
