﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FuncLibrary;

/*
* 9/13/2023
* CSC 253
* Kevin McCroary
* Sorts words from a file into a dictionary with the words as keys and the lines they appear in as values
*/

namespace WinUI
{
    public partial class wordIndexForm : Form
    {
        public wordIndexForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Quit the program
            Close();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            // Try to work program without errors
            try
            {
                // Initialize File Names
                openDialog.FileName = "";
                saveDialog.FileName = "index";

                // Get the file from the user
                if (openDialog.ShowDialog() == DialogResult.OK)
                {
                    // Send opened filename to FileHandler library class
                    FileHandler.OpenFile(openDialog.FileName);

                    // Save the output file
                    if (saveDialog.ShowDialog() == DialogResult.OK)
                    {
                        // Save the output file
                        FileHandler.SaveFile(saveDialog.FileName);

                        // Read open file and write to saved file
                        var dict = WordsHandler.ToDict(FileHandler.inputFile);
                        dict = WordsHandler.SortDict(dict);
                        FileHandler.DictToFile(dict);

                        // Close Files
                        FileHandler.CloseFiles();

                        // Display message
                        MessageBox.Show("Words Indexed");
                    }
                }
            }
            // Error
            catch (Exception ex)
            {
                // Show error message
                MessageBox.Show(ex.Message);
            }
        }
    }
}
