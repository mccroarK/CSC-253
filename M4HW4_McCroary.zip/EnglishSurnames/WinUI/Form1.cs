﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SurnameLibrary;

/*
* 10/22/2023
* CSC 253
* Kevin McCroary
* Allows the user to search through surnames using search criteria and input.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        // Name serach criteria
        string[] searchCriteria = {
            "Longer Than",
            "Shorter Than",
            "Begins With",
            "Specified Name"
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Change combo box data source
            searchComboBox.DataSource = searchCriteria;

            // Load all names
            LoadName.Run();

            // Place names into list box
            nameListBox.DataSource = LoadName.namesList;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close App
            Close();
        }

        private void filterButton_Click(object sender, EventArgs e)
        {
            // Create empty name list
            List<string> sortedList = new List<string>();

            // If search is not empty
            if (searchTextBox.Text != "") {
                // Try
                try
                {
                    // Filter switch
                    switch (searchComboBox.SelectedIndex)
                    {
                        case 0:     // Longer Than
                            sortedList = Filter.LongerThan(int.Parse(searchTextBox.Text));
                            break;

                        case 1:     // Shorter Than
                            sortedList = Filter.ShorterThan(int.Parse(searchTextBox.Text));
                            break;

                        case 2:     // Starts With
                            sortedList = Filter.StartsWith(searchTextBox.Text);
                            break;

                        default:    // Specified Name
                            sortedList = Filter.Specified(searchTextBox.Text);
                            break;
                    }
                }
                // Catch errors
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                }
            }
            // If search is empty
            else
            {
                // Set sorted list to name list
                sortedList = LoadName.namesList;
            }

            // Set name list box data source
            nameListBox.DataSource = sortedList;
        }
    }
}
