﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SurnameLibrary
{
    public static class Filter
    {
        public static List<string> LongerThan(int input)
        {
            // Create a list
            List<string> namelist = new List<string>();

            // Filter
            namelist = LoadName.namesList.FindAll(x => x.Length > input);

            // Return the list
            return namelist;
        }

        public static List<string> ShorterThan(int input)
        {
            // Create a list
            List<string> namelist = new List<string>();

            // Filter
            namelist = LoadName.namesList.FindAll(x => x.Length < input);

            // Return the list
            return namelist;
        }

        public static List<string> StartsWith(string input)
        {
            // Create a list
            List<string> namelist = new List<string>();

            // Filter
            namelist = LoadName.namesList.FindAll(x => x.ToLower().StartsWith(input.ToLower()));

            // Return the list
            return namelist;
        }

        public static List<string> Specified(string input)
        {
            // Create a list
            List<string> namelist = new List<string>();

            // Filter
            namelist.Add(LoadName.namesList.Find(x => x.ToLower() == input.ToLower()));

            // Return the list
            return namelist;
        }
    }
}
