﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SurnameLibrary
{
    public static class LoadName
    {
        public static List<string> namesList = new List<string>();

        public static void Run()
        {
            // Load the names into the list
            using (StreamReader reader = File.OpenText(@"..\..\..\SurnameLibrary\Docs\surnames.txt"))
            {
                // While file has not ended
                while (!reader.EndOfStream)
                {
                    // Fill the surnames list
                    namesList.Add(reader.ReadLine());
                }
            }
        }
    }
}
