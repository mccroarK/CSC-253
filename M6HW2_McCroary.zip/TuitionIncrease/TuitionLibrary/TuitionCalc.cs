﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuitionLibrary
{
    public class TuitionCalc
    {
        public static decimal[] Increase(decimal tuition, int percent, int years)
        {
            // Initialize costs array variable
            decimal[] costs = new decimal[years + 1];

            // Add initial tuition cost
            costs[0] = tuition;

            // Loop for year amount of time
            for (int i = 1; i < years + 1; i++)
            {
                // Add first cost + percentage of last cost to the power of the year
                costs[i] = costs[0] * ((decimal) Math.Pow(1 + ((double) 2 / 100), i));
            }

            // return cost arrays
            return costs;
        }
    }
}
