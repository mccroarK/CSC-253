﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TuitionTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
