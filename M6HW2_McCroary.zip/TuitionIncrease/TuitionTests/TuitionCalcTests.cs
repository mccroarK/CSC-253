﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using TuitionLibrary;

namespace TuitionTests
{
    [TestClass]
    public class TuitionCalcTests
    {
        [TestMethod]
        public void IncreaseTest()
        {
            // Call tuition calculator
            decimal[] actual_costs = TuitionCalc.Increase(6000m, 2, 5);

            // Expected answer
            decimal[] expected_costs = new decimal[] {
                6000m,
                6000m * ((decimal) Math.Pow((double) 1 + ((double) 2 / 100), 1)),
                6000m * ((decimal) Math.Pow((double) 1 + ((double) 2 / 100), 2)),
                6000m * ((decimal) Math.Pow((double) 1 + ((double) 2 / 100), 3)),
                6000m * ((decimal) Math.Pow((double) 1 + ((double) 2 / 100), 4)),
                6000m * ((decimal) Math.Pow((double) 1 + ((double) 2 / 100), 5))
            };

            // Compared expected costs and produced costs
            CollectionAssert.AreEqual(expected_costs, actual_costs, "Cost arrays are not equal");
        }
    }
}
