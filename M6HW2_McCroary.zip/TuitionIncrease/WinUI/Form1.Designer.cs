﻿namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.closeBTN = new System.Windows.Forms.Button();
            this.titleLBL = new System.Windows.Forms.Label();
            this.infoLabel = new System.Windows.Forms.Label();
            this.tuitionLB = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // closeBTN
            // 
            this.closeBTN.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.closeBTN.Location = new System.Drawing.Point(192, 186);
            this.closeBTN.Name = "closeBTN";
            this.closeBTN.Size = new System.Drawing.Size(75, 23);
            this.closeBTN.TabIndex = 0;
            this.closeBTN.Text = "Close";
            this.closeBTN.UseVisualStyleBackColor = true;
            this.closeBTN.Click += new System.EventHandler(this.closeBTN_Click);
            // 
            // titleLBL
            // 
            this.titleLBL.AutoSize = true;
            this.titleLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLBL.Location = new System.Drawing.Point(36, 9);
            this.titleLBL.Name = "titleLBL";
            this.titleLBL.Size = new System.Drawing.Size(201, 29);
            this.titleLBL.TabIndex = 1;
            this.titleLBL.Text = "Tuition Increase";
            // 
            // infoLabel
            // 
            this.infoLabel.Location = new System.Drawing.Point(12, 38);
            this.infoLabel.Name = "infoLabel";
            this.infoLabel.Size = new System.Drawing.Size(255, 39);
            this.infoLabel.TabIndex = 2;
            this.infoLabel.Text = "Shows the tuition increase in the next 5 years starting from $6000.";
            this.infoLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tuitionLB
            // 
            this.tuitionLB.FormattingEnabled = true;
            this.tuitionLB.ItemHeight = 16;
            this.tuitionLB.Location = new System.Drawing.Point(60, 80);
            this.tuitionLB.Name = "tuitionLB";
            this.tuitionLB.Size = new System.Drawing.Size(152, 100);
            this.tuitionLB.TabIndex = 3;
            // 
            // Form1
            // 
            this.AcceptButton = this.closeBTN;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.closeBTN;
            this.ClientSize = new System.Drawing.Size(284, 217);
            this.Controls.Add(this.tuitionLB);
            this.Controls.Add(this.infoLabel);
            this.Controls.Add(this.titleLBL);
            this.Controls.Add(this.closeBTN);
            this.Name = "Form1";
            this.Text = "Tuition Increase";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button closeBTN;
        private System.Windows.Forms.Label titleLBL;
        private System.Windows.Forms.Label infoLabel;
        private System.Windows.Forms.ListBox tuitionLB;
    }
}

