﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuitionLibrary;

/**
* 12/9/2023
* CSC 253
* Kevin McCroary
* Displays the tuition for a college over the next five years.
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void closeBTN_Click(object sender, EventArgs e)
        {
            // Close form
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Increase tuition count by 2% for 5 years
            decimal[] costs = TuitionCalc.Increase(6000, 2, 5);

            // Display all costs
            for (int i = 0; i < costs.Length; i++)
            {
                // Display year and cost
                tuitionLB.Items.Add($"Year {i}:\t{costs[i].ToString("c")}");
            }
        }
    }
}
