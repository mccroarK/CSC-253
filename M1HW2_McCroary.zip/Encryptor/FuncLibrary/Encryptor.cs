﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/**
* 9/9/2023
* CSC 253
* Kevin McCroary
* Program that will encrypt and decrypt files given to it.
*/

namespace FuncLibrary
{
    public static class Encryptor
    {
        static Dictionary<char, char> codes;
        static Dictionary<char, char> decodes;

        public static void Initialize()
        {
            // Create an empty dictionary
           var code_dict = new Dictionary<char, char>();
           var decode_dict = new Dictionary<char, char>();

            // Use the stream reader to open the code file
            using (StreamReader reader = File.OpenText(@"../../../FuncLibrary/Docs/codes.txt"))
            {
                // While the file has not reached the last line
                while (!reader.EndOfStream)
                {
                    // Split the lines into a char array
                    char[] tokens = reader.ReadLine().ToCharArray();

                    // Add the first char of the line as the Key, Add the second as the Value
                    code_dict.Add(tokens[0], tokens[1]);
                    decode_dict.Add(tokens[1], tokens[0]);
                }
            }

            // Add to code
            codes = code_dict;
            decodes = decode_dict;
        }

        public static void Encrypt(StreamReader input, StreamWriter output)
        {
            // Using the input file
            using (input)
            {
                // While the input file has not reached the end
                while (!input.EndOfStream)
                {
                    // For each character in the line
                    foreach (char letter in input.ReadLine())
                    {
                        // If the letter is in the code keys
                        if (codes.ContainsKey(letter))
                        {
                            // Write the key value to the output file
                            output.Write(codes[letter]);
                        }
                        // If the letter is not accounted for in normal codes but is in decodes
                        else if (decodes.ContainsKey(letter))
                        {
                            // Write the key value to the output file
                            output.Write(decodes[letter]);
                        }
                        // If the letter is unaccounted for
                        else
                        {
                            output.Write(letter);
                        }
                    }
                }
            }
        }

        public static void Decrypt(StreamReader input, StreamWriter output)
        {
            // Using the input file
            using (input)
            {
                // While the input file has not reached the end
                while (!input.EndOfStream)
                {
                    // For each character in the line
                    foreach (char letter in input.ReadLine())
                    {
                        // If the letter is in the code keys
                        if (decodes.ContainsKey(letter))
                        {
                            // Write the key value to the output file
                            output.Write(decodes[letter]);
                        }
                        // If the letter is not accounted for in normal codes but is in decodes
                        else if (codes.ContainsKey(letter))
                        {
                            // Write the key value to the output file
                            output.Write(codes[letter]);
                        }
                        // If the letter is not accounted for
                        else
                        {
                            // Write the normal letter
                            output.Write(letter);
                        }
                    }
                }
            }
        }
    }
}
