﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using FuncLibrary;

namespace WinUI
{
    public partial class encryptForm : Form
    {
        public encryptForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void encryptButton_Click(object sender, EventArgs e)
        {
            // Try to work program without errors
            try
            {
                // Initialize input and output file
                StreamReader inputFile;
                StreamWriter outputFile;

                // Clear the file names
                openDialog.FileName = "";
                saveDialog.FileName = "";

                // Get the file from the user
                if (openDialog.ShowDialog() == DialogResult.OK)
                {
                    // Open the text file
                    inputFile = File.OpenText(openDialog.FileName);

                    // Save the output file
                    if (saveDialog.ShowDialog() == DialogResult.OK)
                    {
                        // Create the output file
                        outputFile = File.CreateText(saveDialog.FileName);

                        // Encrypt the file
                        Encryptor.Encrypt(inputFile, outputFile);

                        // Close the files
                        inputFile.Close();
                        outputFile.Close();

                        // Display encrypted message
                        MessageBox.Show("File encrypted");
                    }
                }
            }
            // Catch errors
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void encryptForm_Load(object sender, EventArgs e)
        {
            // On load, initialize codes
            Encryptor.Initialize();
        }

        private void decryptButton_Click(object sender, EventArgs e)
        {
            // Try to work program without errors
            try
            {
                // Initialize input and output file
                StreamReader inputFile;
                StreamWriter outputFile;

                // Clear the file names
                openDialog.FileName = "";
                saveDialog.FileName = "";

                // Get the file from the user
                if (openDialog.ShowDialog() == DialogResult.OK)
                {
                    // Open the text file
                    inputFile = File.OpenText(openDialog.FileName);

                    // Save the output file
                    if (saveDialog.ShowDialog() == DialogResult.OK)
                    {
                        // Create the output file
                        outputFile = File.CreateText(saveDialog.FileName);

                        // Encrypt the file
                        Encryptor.Decrypt(inputFile, outputFile);

                        // Close the files
                        inputFile.Close();
                        outputFile.Close();

                        // Display encrypted message
                        MessageBox.Show("File decrypted");
                    }
                }
            }
            // Catch errors
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
