﻿
namespace WinUI
{
    partial class encryptForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openDialog = new System.Windows.Forms.OpenFileDialog();
            this.nameLabel = new System.Windows.Forms.Label();
            this.helpLabel = new System.Windows.Forms.Label();
            this.encryptButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.saveDialog = new System.Windows.Forms.SaveFileDialog();
            this.encryptLabel = new System.Windows.Forms.Label();
            this.decryptLabel = new System.Windows.Forms.Label();
            this.decryptButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // openDialog
            // 
            this.openDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            this.openDialog.InitialDirectory = "../../../Docs";
            this.openDialog.Title = "Open file to encrypt";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(26, 9);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(245, 29);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Encryptor/Decryptor";
            // 
            // helpLabel
            // 
            this.helpLabel.Location = new System.Drawing.Point(28, 38);
            this.helpLabel.Name = "helpLabel";
            this.helpLabel.Size = new System.Drawing.Size(243, 23);
            this.helpLabel.TabIndex = 1;
            this.helpLabel.Text = "Open a file to encrypt or decrypt it.";
            this.helpLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // encryptButton
            // 
            this.encryptButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.encryptButton.Location = new System.Drawing.Point(101, 95);
            this.encryptButton.Name = "encryptButton";
            this.encryptButton.Size = new System.Drawing.Size(83, 28);
            this.encryptButton.TabIndex = 2;
            this.encryptButton.Text = "Open";
            this.encryptButton.UseVisualStyleBackColor = true;
            this.encryptButton.Click += new System.EventHandler(this.encryptButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(209, 207);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // saveDialog
            // 
            this.saveDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            this.saveDialog.InitialDirectory = "../../../WinUI/Docs";
            // 
            // encryptLabel
            // 
            this.encryptLabel.AutoSize = true;
            this.encryptLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.encryptLabel.Location = new System.Drawing.Point(111, 75);
            this.encryptLabel.Name = "encryptLabel";
            this.encryptLabel.Size = new System.Drawing.Size(63, 17);
            this.encryptLabel.TabIndex = 4;
            this.encryptLabel.Text = "Encrypt";
            // 
            // decryptLabel
            // 
            this.decryptLabel.AutoSize = true;
            this.decryptLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.decryptLabel.Location = new System.Drawing.Point(110, 150);
            this.decryptLabel.Name = "decryptLabel";
            this.decryptLabel.Size = new System.Drawing.Size(64, 17);
            this.decryptLabel.TabIndex = 6;
            this.decryptLabel.Text = "Decrypt";
            // 
            // decryptButton
            // 
            this.decryptButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.decryptButton.Location = new System.Drawing.Point(100, 170);
            this.decryptButton.Name = "decryptButton";
            this.decryptButton.Size = new System.Drawing.Size(83, 28);
            this.decryptButton.TabIndex = 5;
            this.decryptButton.Text = "Open";
            this.decryptButton.UseVisualStyleBackColor = true;
            this.decryptButton.Click += new System.EventHandler(this.decryptButton_Click);
            // 
            // encryptForm
            // 
            this.AcceptButton = this.encryptButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(296, 242);
            this.Controls.Add(this.decryptLabel);
            this.Controls.Add(this.decryptButton);
            this.Controls.Add(this.encryptLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.encryptButton);
            this.Controls.Add(this.helpLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "encryptForm";
            this.Text = "Encryptor";
            this.Load += new System.EventHandler(this.encryptForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openDialog;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label helpLabel;
        private System.Windows.Forms.Button encryptButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.SaveFileDialog saveDialog;
        private System.Windows.Forms.Label encryptLabel;
        private System.Windows.Forms.Label decryptLabel;
        private System.Windows.Forms.Button decryptButton;
    }
}

