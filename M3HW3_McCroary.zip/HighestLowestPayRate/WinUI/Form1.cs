﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
* 10/16/2023
* CSC 253
* Kevin McCroary
* Allows the user to view the highest and lowest hourly pay rate entries in the Employee table.
*/


namespace WinUI
{
    public partial class highestlowestForm : Form
    {
        public highestlowestForm()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the App
            Close();
        }

        private void maxButton_Click(object sender, EventArgs e)
        {
            // Cast pay rate to variable to allow string formatting
            decimal pay = (decimal)employeeTableAdapter.HighestPay();
            // Show maximum/highest pay rate
            MessageBox.Show(pay.ToString("c"));
        }

        private void minButton_Click(object sender, EventArgs e)
        {
            // Cast pay rate to variable to allow string formatting
            decimal pay = (decimal)employeeTableAdapter.LowestPay();
            // Show minimum/lowest pay rate
            MessageBox.Show(pay.ToString("c"));
        }
    }
}
