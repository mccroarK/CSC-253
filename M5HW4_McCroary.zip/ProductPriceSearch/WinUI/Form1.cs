﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
* 11/26/2023
* CSC 253
* Kevin McCroary
* Allows user to search products using a minimum and maximum price range
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Products data context object (Database)
            ProductsDataContext db = new ProductsDataContext();

            // Order all products in the Products table by price (Ascending Order)
            var results = from product in db.Products
                          orderby product.Price ascending
                          select product;

            // Add the product objects to the Data Grid View
            productDataGridView.DataSource = results;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close app
            Close();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Reset search filters
            minTextBox.Clear();
            maxTextBox.Clear();

            // Products data context object (Database)
            ProductsDataContext db = new ProductsDataContext();

            // Order all products in the Products table by price (Ascending Order)
            var results = from product in db.Products
                          orderby product.Price ascending
                          select product;

            // Repopulate data grid view
            productDataGridView.DataSource = results;
        }

        private void filterButton_Click(object sender, EventArgs e)
        {
            // Products data context object (Database)
            ProductsDataContext db = new ProductsDataContext();

            // Fill the results
            var results = from product in db.Products
                          orderby product.Price ascending
                          select product;

            // Get results using minimum price and maximum price searches
            try
            {
                // If minimum price search is not empty
                if (minTextBox.Text != "")
                {
                    // Filter results using the minimum price input
                    results = from product in results
                              where product.Price >= decimal.Parse(minTextBox.Text)
                              orderby product.Price ascending
                              select product;
                }

                // If maximum price search is not empty
                if (maxTextBox.Text != "")
                {
                    // Filter results using the maximum price input
                    results = from product in results
                              where product.Price <= decimal.Parse(maxTextBox.Text)
                              orderby product.Price ascending
                              select product;
                }

                // Display results
                productDataGridView.DataSource = results;
            }

            // Catch errors
            catch(Exception error)
            {
                // Display error message
                MessageBox.Show(error.Message);
            }
        }
    }
}
