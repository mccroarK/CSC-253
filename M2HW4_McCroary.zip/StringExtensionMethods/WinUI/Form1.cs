﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExtensionLibrary;

/**
* 9/28/2023
* CSC 253
* Kevin McCroary
* Allows a user to enter a string and choose an extension method to affect them.
*/

namespace WinUI
{
    public partial class stringExtForm : Form
    {
        // Method choices array
        string[] method_choices =
        {
            "To Char Array",
            "To Date",
            "To Phone Number",
            "To Backwards Text",
            "To Word Count"
        };

        public stringExtForm()
        {
            InitializeComponent();
        }

        private void stringExtForm_Load(object sender, EventArgs e)
        {
            // change the combo box datasource to the choices array
            methodComboBox.DataSource = method_choices;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the program
            Close();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            // Switch depending on method choice
            switch (methodComboBox.SelectedIndex)
            {
                // To Char Array chosen
                case 0:
                    // Create char array and print string
                    char[] chararray = inputTextBox.Text.MakeCharArray();
                    string charstring = "";

                    // Display char array
                    for (int i = 0; i < chararray.Length; i++)
                    {
                        // Add last char to string
                        if (i == chararray.Length - 1)
                        {
                            charstring += chararray[i];
                        }
                        // Add char to string with comma
                        else
                        {
                            charstring += chararray[i] + ", ";
                        }
                    }

                    // Display char array output
                    MessageBox.Show(charstring);

                    // Break
                    break;

                // To Date chosen
                case 1:
                    // Get date
                    string[] date = inputTextBox.Text.ToDate();
                    
                    // Show date output
                    if (date.Length > 1)
                    {
                        MessageBox.Show(
                            $"Month:\t{date[0]}\n" +
                            $"Day:\t{date[1]}\n" +
                            $"Year:\t{date[2]}");
                    }
                    else
                    {
                        MessageBox.Show(date[0]);
                    }

                    // Break
                    break;

                // To Phone Number chosen
                case 2:
                    // Show phone number output
                    MessageBox.Show(inputTextBox.Text.ToPhoneNumber());
                    // Break
                    break;

                // To Backwards Text chosen
                case 3:
                    // Show backwards text
                    MessageBox.Show(inputTextBox.Text.ToBackwards());
                    // Break
                    break;

                // To Word Count
                default:
                    // Show word count
                    MessageBox.Show($"Word Count: {inputTextBox.Text.ToWordCount()}");
                    // Break
                    break;
            }
        }
    }
}
