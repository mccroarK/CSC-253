﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionLibrary
{
    public static class Extensions
    {
        public static char[] MakeCharArray(this string input)
        {
            // Return the char array (this is already a method???)
            return input.ToCharArray();
        }
        public static string[] ToDate(this string input)
        {
            // Datetime object
            DateTime date = new DateTime();

            // Split string
            if (DateTime.TryParse(input, out date))
            {
                return new string[] { date.Month.ToString(), date.Day.ToString(), date.Year.ToString()};
            }
            else
            {
                return new string[] { "Incorrect input"};
            }
        }

        public static string ToPhoneNumber(this string input)
        {
            // Try to convert user string to phone number
            try
            {
                // Check if input can be a number
                int.Parse(input);

                // Return phone number string
                return $"({input.Substring(0, 3)}) {input.Substring(3, 3)}-{input.Substring(6, 4)}";
            }
            // User inputs incorrect string
            catch
            {
                return "Please input 10 number characters";
            }
        }

        public static string ToBackwards(this string input)
        {
            // Create an empty string variable
            string reverse = "";

            // Loop through user inputted string backwards
            for (int i = input.Length - 1; i >= 0; i--)
            {
                // Add letters
                reverse += input[i];
            }

            // Return reversed string
            return reverse;
        }

        public static int ToWordCount(this string input)
        {
            // If input string is not empty
            if (input != "")
            {
                // Split string into array using the space character and return the length
                return input.Split(' ').Length;
            }
            else
            {
                // return 0
                return 0;
            }
            
        }
    }
}
