﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
* 11/26/2023
* CSC 253
* Kevin McCroary
* Allows a user to search products by number and description
*/

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Products data context object (Database)
            ProductsDataContext db = new ProductsDataContext();

            // Get all of the product objects in the Products Table
            var results = from product in db.Products
                          select product;

            // Add the product objects to the Data Grid View
            productDataGridView.DataSource = results;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the app
            Close();
        }

        private void filterButton_Click(object sender, EventArgs e)
        {
            // Products data context object (Database)
            ProductsDataContext db = new ProductsDataContext();

            // Fill the results
            var results = from product in db.Products
                          select product;

            // Get results using number and description searches
            try
            {
                // If number search is not empty
                if (prodNumTextBox.Text != "")
                {
                    // Filter results using the number search
                    results = from product in results
                              where product.Product_Number.Contains(prodNumTextBox.Text)    // Prod number is not an int my bad
                              select product;
                }

                // If description search is not empty
                if (prodDescTextBox.Text != "")
                {
                    // Filter results using the description search
                    results = from product in results
                              where product.Description.Contains(prodDescTextBox.Text)
                              select product;
                }
            }

            // Catch any errors
            catch (Exception error)
            {
                // Print error message
                MessageBox.Show(error.Message);
            }

            // Display results
            productDataGridView.DataSource = results;
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            // Reset filters
            prodNumTextBox.Text = "";
            prodDescTextBox.Text = "";

            // Products data context object (Database)
            ProductsDataContext db = new ProductsDataContext();

            // Fill the results
            var results = from product in db.Products
                          select product;

            // Repopulate data grid view
            productDataGridView.DataSource = results;
        }
    }
}
